package com.cg.project.dto;

public class Participant {

 private int Roll_no=16000;
 private static int count=0;
 private String email;
 private String scheduledprogramid;
 private String applicationid;
public int getRoll_no() {
	return Roll_no;
}
public  void setRoll_no() {
	this.Roll_no = this.Roll_no+count;
	count++;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getScheduledprogramid() {
	return scheduledprogramid;
}
public void setScheduledprogramid(String scheduledprogramid) {
	this.scheduledprogramid = scheduledprogramid;
}
public String getApplicationid() {
	return applicationid;
}
public void setApplicationid(String applicationid) {
	this.applicationid = applicationid;
}
 
 
 
 
}
