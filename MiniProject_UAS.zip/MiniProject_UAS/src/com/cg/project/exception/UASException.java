package com.cg.project.exception;

public class UASException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UASException() {
		super();
		
	}

	public UASException(String message, Throwable cause) {
		super(message, cause);
		
	}

	
}
