package com.cg.project.service;



import com.cg.project.dao.AdminDAO;
import com.cg.project.dao.AdminDAOImpl;
import com.cg.project.dto.ProgramsOffered;
import com.cg.project.dto.ProgramsScheduled;
import com.cg.project.exception.UASException;

public class AdminDAOServiceImpl implements AdminDAOService{

	AdminDAO daoref = new AdminDAOImpl();
	
//	Login verification...
	
	@Override
	public String loginverification(String login_id,String user_password)throws UASException
	{
		return daoref.loginverification(login_id,user_password);
	}

	
//	Retrieval of programs in the university...
	
	@Override
	public void retrieveprograms() throws UASException
	{
		daoref.retrieveprograms();
	}

//	Creating programs for applicants in the university...
	
	@Override
	public boolean createprogram(ProgramsOffered progoff,ProgramsScheduled progsch) throws UASException
	{
		boolean a= daoref.createprogram(progoff,progsch);
		 return a;
	}
	
	

//	Deleting programs...
	
	@Override
	public boolean deleteprogram(String name) throws UASException
	{    boolean  a;
		 a= daoref.deleteprogram(name);
		 return a;
	}

	
//Scheduling programs... 	
	@Override
	public void scheduledprogramsinfo(String start_date,String end_date) throws UASException
	{
		daoref.scheduledprogramsinfo(start_date, end_date);
	}
	
	
//	Displaying applicants on particular program and status
	@Override
	public void finallist(String programname,String status) throws UASException
	{
		daoref.finallist(programname, status);
	}
	
//	Displaying total number of applicants... 
	
	@Override
	public int countapplicants(String progid) throws UASException
	{
		return daoref.countapplicants(progid);
	}

//Updating programs in the university..
	
	@Override
	public boolean updateprogram(String progid, String startdate, String enddate, int sessions, String location) throws UASException
	{
		boolean a= daoref.updateprogram(progid, startdate, enddate, sessions, location);
		return a;
	}
	
	
}
